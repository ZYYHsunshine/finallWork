package com.twschool.practice;

import org.junit.Assert;
import org.junit.Test;

public class HelloTest {

    @Test
    public void should_run_test_pass() {
        Assert.assertTrue(true);
    }
}
