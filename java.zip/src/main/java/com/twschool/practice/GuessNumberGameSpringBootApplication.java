package com.twschool.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuessNumberGameSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(GuessNumberGameSpringBootApplication.class, args);
    }
}
