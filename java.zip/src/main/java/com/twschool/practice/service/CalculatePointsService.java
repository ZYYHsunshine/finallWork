package com.twschool.practice.service;

import org.springframework.stereotype.Service;

@Service
public class CalculatePointsService {
    private static int continueWinCount = 0;
    private static int scores = 0;

    public int addPoint() {
        scores = scores + 3;
        if (continueWinCount % 3 == 0){
            scores = scores + 2;
        }
        if (continueWinCount % 5 == 0){
            scores = scores + 3;
        }
        return scores;
    }

    public int subPoint() {
        scores = scores - 3;
        return scores;
    }

    public void isContinueWin(String result){
        if (result.equals("4A0B")){
            continueWinCount ++;
        }else {
            continueWinCount = 0;
        }
    }

}
