package com.twschool.practice.console;

public class ConsoleOutputWriter {
    public void output(String message) {
        System.out.println(message);
    }
}
